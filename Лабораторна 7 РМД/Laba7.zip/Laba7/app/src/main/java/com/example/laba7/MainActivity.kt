package com.example.laba7

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.laba7.ui.theme.Laba7Theme
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.random.Random

class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var onSensorData: ((Float, Float) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        setContent {
            Laba7Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF040404)
                ) {
                    BallGame { callback ->
                        onSensorData = callback
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accelerometer?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            val x = -event.values[0]
            val y = event.values[1]
            onSensorData?.invoke(x, y)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

@Composable
fun BallGame(onSensorConnected: (callback: (Float, Float) -> Unit) -> Unit) {
    var ballX by remember { mutableStateOf(500f) }
    var ballY by remember { mutableStateOf(800f) }
    var targetX by remember { mutableStateOf(800f) }
    var targetY by remember { mutableStateOf(400f) }
    var score by remember { mutableStateOf(0) }

    val ballRadius = 60f
    val targetRadius = 70f
    val speed = 6f

    var dx by remember { mutableStateOf(0f) }
    var dy by remember { mutableStateOf(0f) }
    var isRunning by remember { mutableStateOf(false) }

    onSensorConnected { x, y ->
        if (isRunning) {
            dx = x
            dy = y
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B262B))
    ) {
        // Canvas для кульки та мішені
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            if (isRunning) {
                ballX += dx * speed
                ballY += dy * speed
            }

            // Межі екрану
            if (ballX - ballRadius < 0) ballX = ballRadius
            if (ballX + ballRadius > width) ballX = width - ballRadius
            if (ballY - ballRadius < 0) ballY = ballRadius
            if (ballY + ballRadius > height) ballY = height - ballRadius

            // Мішень
            drawCircle(
                color = Color(0xFF008080),
                radius = targetRadius,
                center = Offset(targetX, targetY)
            )

            // Кулька
            drawCircle(
                color = Color(0xFF00B1B1),
                radius = ballRadius,
                center = Offset(ballX, ballY)
            )

            // Зіткнення
            val distance = sqrt((ballX - targetX).pow(2) + (ballY - targetY).pow(2))
            if (isRunning && distance < ballRadius + targetRadius) {
                score++
                targetX = Random.nextFloat() * (width - 2 * targetRadius) + targetRadius
                targetY = Random.nextFloat() * (height - 2 * targetRadius) + targetRadius
            }
        }

        // Score через Compose Text
        Text(
            text = "Score: $score",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF114852),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 16.dp, top = 16.dp)
        )

        // Кнопка Start / Restart напівпрозора, трохи нижче
        Button(
            onClick = {
                ballX = 500f
                ballY = 800f
                score = 0
                isRunning = true
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF00B1B1),
                contentColor = Color.White
            ),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp)  // нижче Score
                .width(160.dp)
                .height(48.dp)
                .alpha(0.7f)  // напівпрозора
        ) {
            Text(
                text = if (isRunning) "Restart" else "Start",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }
    }
}
